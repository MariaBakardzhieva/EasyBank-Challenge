$(document).ready(function () {
    $('.mobile-menu').click(function () {
        $('.navigation').toggleClass('navigation--open');
    });
});